import io
import qrcode
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler, MessageHandler,
    ContextTypes, ConversationHandler, filters
)
from sqlalchemy import select, desc

from .config import settings
from .db import init_db, SessionLocal, User, Order, get_rate, set_rate, get_stats

SELL_AMOUNT, PAYMENT, TXID = range(3)

def menu():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("💵 Sell USDT", callback_data="sell"),
         InlineKeyboardButton("🧮 Calculator", callback_data="calc")],
        [InlineKeyboardButton("📜 My Orders", callback_data="orders"),
         InlineKeyboardButton("💳 Payment Details", callback_data="payment")],
        [InlineKeyboardButton("🆘 Support", callback_data="support"),
         InlineKeyboardButton("ℹ️ How It Works", callback_data="how")]
    ])

async def ensure_user(update: Update):
    u = update.effective_user
    async with SessionLocal() as s:
        row = (await s.execute(select(User).where(User.telegram_id == u.id))).scalar_one_or_none()
        if not row:
            s.add(User(telegram_id=u.id, username=u.username))
            await s.commit()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await ensure_user(update)
    rate = await get_rate()
    await update.message.reply_text(
        f"🤖 *USDT → INR Exchange*\n\n"
        f"💱 Current rate: *₹{rate:.2f} / USDT*\n"
        f"🔒 Payments are manually verified by admin.\n\n"
        "Choose an option:",
        parse_mode="Markdown", reply_markup=menu()
    )

async def buttons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if q.data == "sell":
        await q.message.reply_text(
            f"💵 *Sell USDT*\n\nSend the amount of USDT you want to sell.\n"
            f"Minimum: {settings.min_usdt} USDT\nMaximum: {settings.max_usdt} USDT",
            parse_mode="Markdown"
        )
        return SELL_AMOUNT
    if q.data == "calc":
        rate = await get_rate()
        await q.message.reply_text(f"🧮 Rate: ₹{rate:.2f}/USDT\n\nUse: USDT amount × rate")
    elif q.data == "orders":
        async with SessionLocal() as s:
            rows = (await s.execute(
                select(Order).where(Order.telegram_id == q.from_user.id)
                .order_by(desc(Order.created_at)).limit(10)
            )).scalars().all()
        if not rows:
            await q.message.reply_text("📜 You have no orders yet.")
        else:
            text="📜 *Your recent orders*\n\n"
            for o in rows:
                text += f"#{o.id} — {o.usdt_amount:g} USDT → ₹{o.inr_amount:,.2f} — `{o.status}`\n"
            await q.message.reply_text(text, parse_mode="Markdown")
    elif q.data == "payment":
        await q.message.reply_text(
            f"🏦 Your INR payout details are collected per order.\n"
            f"USDT network: *{settings.network}*",
            parse_mode="Markdown"
        )
    elif q.data == "support":
        msg = "🆘 Support\n\n"
        msg += f"Contact: @{settings.support_username}" if settings.support_username else "Please contact the administrator through the bot."
        await q.message.reply_text(msg)
    elif q.data == "how":
        await q.message.reply_text(
            "ℹ️ *How it works*\n\n"
            "1. Enter USDT amount.\n"
            "2. Enter your INR payout details.\n"
            "3. Bot shows the deposit wallet/QR.\n"
            "4. Send USDT and submit TXID.\n"
            "5. Admin verifies the transaction.\n"
            "6. INR payout is processed manually.",
            parse_mode="Markdown"
        )

async def sell_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        amount = float(update.message.text.strip())
        if amount < settings.min_usdt or amount > settings.max_usdt:
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Enter a valid USDT amount within the allowed limits.")
        return SELL_AMOUNT
    rate = await get_rate()
    context.user_data["amount"] = amount
    context.user_data["rate"] = rate
    await update.message.reply_text(
        f"💵 *Sell Summary*\n\nUSDT: `{amount:g}`\nRate: `₹{rate:.2f}`\n"
        f"You receive: *₹{amount*rate:,.2f}*\n\n"
        "Now send your UPI ID or bank payout details.",
        parse_mode="Markdown"
    )
    return PAYMENT

async def payment(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["payment"] = update.message.text.strip()
    amount=context.user_data["amount"]; rate=context.user_data["rate"]
    await update.message.reply_text(
        f"📤 *Send {amount:g} USDT*\n\n"
        f"Network: *{settings.network}*\n"
        f"Wallet:\n`{settings.wallet_address}`\n\n"
        "After sending, enter the blockchain transaction hash (TXID).",
        parse_mode="Markdown"
    )
    if settings.wallet_address:
        img=qrcode.make(settings.wallet_address)
        bio=io.BytesIO(); img.save(bio, format="PNG"); bio.seek(0)
        await update.message.reply_photo(bio, caption="🔳 USDT deposit QR")
    return TXID

async def txid(update: Update, context: ContextTypes.DEFAULT_TYPE):
    tx=update.message.text.strip()
    amount=context.user_data["amount"]; rate=context.user_data["rate"]
    payment_details=context.user_data["payment"]
    async with SessionLocal() as s:
        order=Order(
            telegram_id=update.effective_user.id, usdt_amount=amount, rate=rate,
            inr_amount=amount*rate, upi_or_bank=payment_details, txid=tx,
            status="PENDING_REVIEW"
        )
        s.add(order); await s.commit(); await s.refresh(order)
        oid=order.id
    await update.message.reply_text(
        f"✅ Order #{oid} submitted.\n\n"
        f"USDT: {amount:g}\nINR: ₹{amount*rate:,.2f}\n"
        "Status: *Pending verification*\n\n"
        "Do not send the same TXID to another order.",
        parse_mode="Markdown"
    )
    admin_text=(f"🆕 *SELL ORDER #{oid}*\n\nUser: `{update.effective_user.id}`\n"
                f"USDT: {amount:g}\nRate: ₹{rate:.2f}\nINR: ₹{amount*rate:,.2f}\n"
                f"TXID: `{tx}`\nPayout: `{payment_details}`")
    kb=InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ Mark Paid", callback_data=f"approve:{oid}"),
         InlineKeyboardButton("❌ Reject", callback_data=f"reject:{oid}")]
    ])
    for aid in settings.admin_ids:
        try:
            await context.bot.send_message(aid, admin_text, parse_mode="Markdown", reply_markup=kb)
        except Exception:
            pass
    return ConversationHandler.END

async def admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in settings.admin_ids:
        return
    if not context.args:
        await update.message.reply_text(
            "/admin — dashboard\n/setrate 98\n/stats\n/orders"
        ); return
    await update.message.reply_text("Use /setrate, /stats or /orders.")

async def setrate_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in settings.admin_ids: return
    try: value=float(context.args[0]); assert value>0
    except Exception:
        await update.message.reply_text("Usage: /setrate 98"); return
    await set_rate(value)
    await update.message.reply_text(f"✅ Rate changed to ₹{value:.2f}/USDT.")

async def stats_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in settings.admin_ids: return
    s=await get_stats()
    await update.message.reply_text(
        f"📊 *Dashboard*\n\nUsers: {s['users']}\nOrders: {s['orders']}\n"
        f"Pending: {s['pending']}\nCompleted: {s['completed']}\nRejected: {s['rejected']}\n"
        f"USDT purchased: {s['usdt']:.2f}\nINR paid: ₹{s['inr']:,.2f}", parse_mode="Markdown"
    )

async def admin_action(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q=update.callback_query
    if q.from_user.id not in settings.admin_ids:
        await q.answer("Not authorized.", show_alert=True); return
    await q.answer()
    action, oid=q.data.split(":")
    oid=int(oid)
    async with SessionLocal() as s:
        o=await s.get(Order, oid)
        if not o:
            await q.message.reply_text("Order not found."); return
        o.status="PAID" if action=="approve" else "REJECTED"
        await s.commit()
        uid=o.telegram_id
        status=o.status
        inr=o.inr_amount
    await q.edit_message_reply_markup(reply_markup=None)
    await q.message.reply_text(f"Order #{oid}: {status}")
    try:
        await context.bot.send_message(
            uid,
            f"📦 Order #{oid} updated.\nStatus: *{status}*\n"
            + (f"INR payout: ₹{inr:,.2f}" if status=="PAID" else "Please contact support if you need assistance."),
            parse_mode="Markdown"
        )
    except Exception:
        pass

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("❌ Cancelled.")
    return ConversationHandler.END

async def post_init(app: Application):
    await init_db()

def build_app():
    app=Application.builder().token(settings.bot_token).post_init(post_init).build()
    conv=ConversationHandler(
        entry_points=[CallbackQueryHandler(buttons, pattern="^sell$")],
        states={
            SELL_AMOUNT:[MessageHandler(filters.TEXT & ~filters.COMMAND, sell_amount)],
            PAYMENT:[MessageHandler(filters.TEXT & ~filters.COMMAND, payment)],
            TXID:[MessageHandler(filters.TEXT & ~filters.COMMAND, txid)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
        per_user=True, per_chat=True
    )
    app.add_handler(CommandHandler("start", start))
    app.add_handler(conv)
    app.add_handler(CallbackQueryHandler(buttons, pattern="^(calc|orders|payment|support|how)$"))
    app.add_handler(CallbackQueryHandler(admin_action, pattern="^(approve|reject):\d+$"))
    app.add_handler(CommandHandler("admin", admin))
    app.add_handler(CommandHandler("setrate", setrate_cmd))
    app.add_handler(CommandHandler("stats", stats_cmd))
    return app

if __name__=="__main__":
    build_app().run_polling()
