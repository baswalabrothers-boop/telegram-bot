from datetime import datetime
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy import String, Float, Integer, DateTime, Text, select

from .config import settings

engine = create_async_engine(settings.database_url, future=True)
SessionLocal = async_sessionmaker(engine, expire_on_commit=False)

class Base(DeclarativeBase):
    pass

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    telegram_id: Mapped[int] = mapped_column(Integer, unique=True, index=True)
    username: Mapped[str | None] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Order(Base):
    __tablename__ = "orders"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    telegram_id: Mapped[int] = mapped_column(Integer, index=True)
    usdt_amount: Mapped[float] = mapped_column(Float)
    rate: Mapped[float] = mapped_column(Float)
    inr_amount: Mapped[float] = mapped_column(Float)
    upi_or_bank: Mapped[str] = mapped_column(Text)
    txid: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(30), default="AWAITING_TXID")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Setting(Base):
    __tablename__ = "settings"
    key: Mapped[str] = mapped_column(String(100), primary_key=True)
    value: Mapped[str] = mapped_column(Text)

async def init_db():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    async with SessionLocal() as s:
        if not (await s.get(Setting, "rate")):
            s.add(Setting(key="rate", value=str(settings.exchange_rate)))
        await s.commit()

async def get_rate() -> float:
    async with SessionLocal() as s:
        row = await s.get(Setting, "rate")
        return float(row.value) if row else settings.exchange_rate

async def set_rate(value: float):
    async with SessionLocal() as s:
        row = await s.get(Setting, "rate")
        if row:
            row.value = str(value)
        else:
            s.add(Setting(key="rate", value=str(value)))
        await s.commit()

async def get_stats():
    async with SessionLocal() as s:
        orders = (await s.execute(select(Order))).scalars().all()
        users = (await s.execute(select(User))).scalars().all()
        return {
            "users": len(users),
            "orders": len(orders),
            "pending": sum(o.status in ("AWAITING_TXID", "PENDING_REVIEW") for o in orders),
            "completed": sum(o.status == "PAID" for o in orders),
            "rejected": sum(o.status == "REJECTED" for o in orders),
            "usdt": sum(o.usdt_amount for o in orders if o.status == "PAID"),
            "inr": sum(o.inr_amount for o in orders if o.status == "PAID"),
        }
