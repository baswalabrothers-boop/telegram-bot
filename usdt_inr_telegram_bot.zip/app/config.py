import os
from dataclasses import dataclass

@dataclass(frozen=True)
class Settings:
    bot_token: str = os.getenv("BOT_TOKEN", "")
    admin_ids: tuple[int, ...] = tuple(
        int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip()
    )
    database_url: str = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///./bot.db")
    exchange_rate: float = float(os.getenv("EXCHANGE_RATE", "98"))
    min_usdt: float = float(os.getenv("MIN_USDT", "1"))
    max_usdt: float = float(os.getenv("MAX_USDT", "10000"))
    wallet_address: str = os.getenv("USDT_WALLET_ADDRESS", "")
    network: str = os.getenv("USDT_NETWORK", "TRC20")
    support_username: str = os.getenv("SUPPORT_USERNAME", "")
    webhook_url: str = os.getenv("WEBHOOK_URL", "")
    webhook_secret: str = os.getenv("WEBHOOK_SECRET", "change-me")

settings = Settings()

if not settings.bot_token:
    raise RuntimeError("BOT_TOKEN is required")
if not settings.admin_ids:
    raise RuntimeError("ADMIN_IDS is required")
