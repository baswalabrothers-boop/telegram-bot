# USDT → INR Telegram Bot

A Telegram bot for creating USDT-to-INR sell orders with manual admin verification.

## Important
This repository does **not** automatically verify blockchain deposits or automatically send INR. It creates orders, collects a TXID, and lets an authorized admin mark an order paid/rejected.

Before operating a real VDA/fiat exchange service in India, obtain appropriate legal, tax, AML/KYC and FIU-IND advice/registration where applicable.

## 1. Create the bot
Use Telegram @BotFather. If a token was exposed publicly, revoke it and create a new one.

## 2. Configure
Copy `.env.example` to `.env` and set:
- BOT_TOKEN
- ADMIN_IDS
- USDT_WALLET_ADDRESS
- USDT_NETWORK

Never commit `.env`.

## 3. Local run
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
python -m app.main
```

## 4. Choreo
Create a GitHub repository from this folder and connect it to Choreo as a containerized/service deployment.

Set the environment variables from `.env.example` in Choreo. For production, use PostgreSQL:
`DATABASE_URL=postgresql+asyncpg://USER:PASSWORD@HOST:5432/DBNAME`

Set a stable `ADMIN_IDS` value to your Telegram numeric user ID.

## Admin commands
`/admin`
`/setrate 98`
`/stats`

Admin approval buttons appear for each submitted order.

## Production upgrades recommended
- KYC/AML workflow
- sanctions/PEP screening where legally required
- blockchain API/RPC verification
- confirmation thresholds
- duplicate TXID detection
- unique deposit addresses
- rate locking/expiry
- payout provider integration
- withdrawal reconciliation
- audit log table
- role-based admin permissions
- PostgreSQL backups
- webhook deployment
- rate limiting and anti-spam controls
